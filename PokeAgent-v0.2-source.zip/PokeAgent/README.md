# PokéAgent 0.2 — Android nativo

Aplicativo Kotlin para Android que captura a tela com MediaProjection e envia toques/pressões ao My Boy! por AccessibilityService. O projeto foi estruturado para Android 8+ e aparelhos intermediários como o Redmi Note 12 (6 GB RAM). Não usa Termux, root, computador durante o uso, APIs pagas ou chamadas de rede.

## O que está implementado

- Tela de configuração para habilitar o serviço de acessibilidade, conceder sobreposição e iniciar a captura de tela.
- Serviço em primeiro plano para MediaProjection, com notificação persistente.
- Controle flutuante arrastável com **INICIAR/PAUSAR**, **DESATIVAR** (interrompe os toques e encerra a captura) e **FECHAR**.
- Toques enviados por AccessibilityService; posições configuradas como coordenadas relativas à tela de 0 a 1000.
- Leitura visual local leve, amostrando cores e regiões para estimar exploração, batalha, diálogo, menu ou tela desconhecida.
- Decisor local: tenta confirmar com A em batalhas/menus/diálogos e percorre direções em sequência durante exploração. Telas desconhecidas não recebem comandos.
- Memória local de modo, última ação e contagem de ações no armazenamento privado do app.
- Workflow de GitHub Actions para gerar APK debug.

## Limitações conhecidas

O classificador é heurístico, sem OCR e sem modelo de visão treinado. A confiança é apenas uma indicação interna, não uma probabilidade calibrada. Ele pode confundir telas, considerar elementos do controle flutuante e pressionar A em uma situação inesperada. O decisor não conhece a missão real, inventário, equipe, vida ou objetivos da ROM Pokémon Quetzal. As decisões são simples e não garantem progresso no jogo.

É preciso calibrar os pontos no layout e escala usados no My Boy!. Neste protótipo, a direção de movimento é uma pressão curta repetida; não há análise de posição do personagem, navegação de mapa, leitura de texto, combate estratégico ou recuperação de erros. Redmi Note 12 não foi testado fisicamente; consumo, aquecimento, sobrevivência em segundo plano e diferenças entre versões MIUI/HyperOS ainda precisam de teste.

## Como usar no Android

1. Instale o APK debug gerado pelo Actions.
2. Abra PokéAgent e habilite **PokéAgent** em Configurações → Acessibilidade. O sistema mostra um aviso porque o serviço pode operar a tela.
3. Permita a sobreposição do app.
4. No My Boy!, abra a ROM e mantenha visíveis os botões na tela. Anote a posição aproximada dos botões do direcional e A; em PokéAgent, configure X/Y de cada um na escala 0–1000 e salve. Ex.: centro da tela = 500,500.
5. Volte ao PokéAgent e toque **Iniciar captura de tela**. Confirme a solicitação de captura do Android.
6. Volte ao jogo e use o controle flutuante. **PAUSAR** para interromper ações mantendo captura; **DESATIVAR** para parar tudo imediatamente.
7. Comece supervisionando em uma área segura do jogo. Se os pontos estiverem errados, pause e recalibre.

MediaProjection exige consentimento do usuário em cada nova sessão. O Android/MIUI pode encerrar processos em segundo plano; o serviço em primeiro plano reduz essa chance, mas não promete funcionamento contínuo. O controle flutuante pode aparecer na captura; mova-o para uma área vazia.

## Gerar APK pelo GitHub Actions sem computador

1. Crie um repositório GitHub pelo navegador do Android e envie o conteúdo desta pasta, mantendo a estrutura de diretórios.
2. Abra **Actions → Build Android APK → Run workflow** (ou envie para `main`/`master`).
3. Quando a execução terminar, baixe o artefato **PokeAgent-debug-apk** e instale `app-debug.apk`.

A versão de debug é assinada com uma chave de desenvolvimento gerada pelo Android Gradle Plugin; não é uma release Play Store.

## Compilação local

Requer JDK 17, Android SDK (plataforma 35 e build-tools recentes) e Gradle 8.9. Na raiz do projeto:

```bash
gradle assembleDebug --no-daemon
```

Saída: `app/build/outputs/apk/debug/app-debug.apk`.

## Testes pendentes no dispositivo

- Confirmar a concessão de MediaProjection e a notificação em Android 13/14/15 com MIUI/HyperOS.
- Confirmar que o APK inicia, AccessibilityService conecta e os gestos acertam os botões do My Boy! após calibração.
- Verificar pausar/desativar durante uma pressão e após bloquear/desbloquear o celular.
- Conferir reconhecimento visual em cenas reais de exploração, batalha, diálogo e menu da versão de Quetzal usada.
- Medir consumo de memória, bateria, aquecimento e estabilidade por pelo menos 30 minutos.
