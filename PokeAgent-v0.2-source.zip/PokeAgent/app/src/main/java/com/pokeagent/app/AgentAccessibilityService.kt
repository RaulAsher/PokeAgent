package com.pokeagent.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class AgentAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: AgentAccessibilityService? = null
            private set
        @Volatile var enabled = false
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() { enabled = false }
    override fun onDestroy() { enabled = false; instance = null; super.onDestroy() }

    fun tap(x: Float, y: Float, durationMs: Long = 85L) {
        if (!enabled) return
        val path = Path().apply { moveTo(x, y); lineTo(x + 0.1f, y + 0.1f) }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceIn(40L, 800L))
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun press(x: Float, y: Float, durationMs: Long) = tap(x, y, durationMs)
}
