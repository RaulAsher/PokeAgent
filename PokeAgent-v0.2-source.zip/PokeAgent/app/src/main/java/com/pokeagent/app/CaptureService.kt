package com.pokeagent.app

import android.app.*
import android.content.pm.ServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.WindowManager
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "com.pokeagent.START_CAPTURE"
        const val ACTION_STOP = "com.pokeagent.STOP_CAPTURE"
        const val EXTRA_RESULT = "result_code"
        const val EXTRA_DATA = "result_data"
        @Volatile var automationOn = false
        @Volatile var status = "Captura parada"
    }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var analysisThread: HandlerThread? = null
    private val busy = AtomicBoolean(false)
    private var lastDecisionAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopCapture(); stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_STICKY
        if (Build.VERSION.SDK_INT >= 29) startForeground(42, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(42, notification())
        val resultCode = intent?.getIntExtra(EXTRA_RESULT, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java) else intent?.getParcelableExtra(EXTRA_DATA)
        if (resultCode != Activity.RESULT_OK || data == null) { status = "Permissão de captura não concedida"; stopSelf(); return START_NOT_STICKY }
        try {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopCapture(); stopSelf() }
            }, null)
            val (width, height, density) = displaySize()
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            analysisThread = HandlerThread("PokeAgentVision").also { it.start() }
            reader?.setOnImageAvailableListener({ source -> analyze(source) }, Handler(analysisThread!!.looper))
            display = projection?.createVirtualDisplay("PokeAgentCapture", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
            status = "Captura ativa; automação pausada"
        } catch (e: Exception) { status = "Falha na captura: ${e.javaClass.simpleName}"; stopCapture(); stopSelf() }
        return START_NOT_STICKY
    }

    private fun displaySize(): Triple<Int, Int, Int> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= 30) {
            val bounds = wm.currentWindowMetrics.bounds
            val density = resources.displayMetrics.densityDpi
            return Triple(bounds.width(), bounds.height(), density)
        } else {
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            return Triple(metrics.widthPixels, metrics.heightPixels, metrics.densityDpi)
        }
    }

    private fun analyze(source: ImageReader) {
        if (!automationOn) { source.acquireLatestImage()?.close(); return }
        if (!busy.compareAndSet(false, true)) { source.acquireLatestImage()?.close(); return }
        val now = System.currentTimeMillis()
        if (now - lastDecisionAt < 1100) { busy.set(false); return }
        lastDecisionAt = now
        try {
            val image = source.acquireLatestImage() ?: return
            image.use {
                val plane = it.planes[0]; val buffer: ByteBuffer = plane.buffer
                val pixelStride = plane.pixelStride; val rowStride = plane.rowStride
                val paddedWidth = rowStride / pixelStride
                val bmp = Bitmap.createBitmap(paddedWidth, it.height, Bitmap.Config.ARGB_8888)
                buffer.rewind(); bmp.copyPixelsFromBuffer(buffer)
                val cropped = Bitmap.createBitmap(bmp, 0, 0, it.width, it.height)
                if (cropped !== bmp) bmp.recycle()
                val reading = ScreenAnalyzer.read(cropped)
                val action = LocalBrain.next(this, reading)
                status = "${reading.mode} (${reading.confidence}%) • ${reading.note} • ação: $action"
                if (action != "NONE") perform(action)
                cropped.recycle()
            }
        } catch (e: Exception) { status = "Erro ao analisar tela: ${e.javaClass.simpleName}" }
        finally { busy.set(false) }
    }

    private fun perform(action: String) {
        val prefs = getSharedPreferences("agent", Context.MODE_PRIVATE)
        val key = "pad_$action"
        val x = prefs.getInt("${key}_x", -1); val y = prefs.getInt("${key}_y", -1)
        if (x < 0 || y < 0) { status += " (configure $action)"; return }
        val (width, height, _) = displaySize()
        AgentAccessibilityService.instance?.tap(width * x / 1000f, height * y / 1000f, if (action == "A") 80 else 240)
            ?: run { status += " (ative Acessibilidade)" }
    }

    private fun notification(): Notification {
        val channelId = "pokeagent_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Captura do PokéAgent", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return Notification.Builder(this, channelId).setContentTitle("PokéAgent")
            .setContentText("Captura de tela em execução").setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true).build()
    }

    private fun stopCapture() {
        automationOn = false; AgentAccessibilityService.enabled = false
        display?.release(); display = null; reader?.close(); reader = null
        analysisThread?.quitSafely(); analysisThread = null
        val oldProjection = projection; projection = null; oldProjection?.stop(); status = "Captura parada"
    }

    override fun onDestroy() { stopCapture(); super.onDestroy() }
}
