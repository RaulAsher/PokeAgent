package com.pokeagent.app

import android.content.Context
import android.graphics.Bitmap
import kotlin.math.max

enum class ScreenMode { EXPLORATION, BATTLE, DIALOGUE, MENU, UNKNOWN }
data class ScreenReading(val mode: ScreenMode, val confidence: Int, val note: String)

/** Lightweight on-device visual heuristics; deliberately reports uncertainty instead of claiming OCR. */
object ScreenAnalyzer {
    fun read(bitmap: Bitmap): ScreenReading {
        val w = bitmap.width; val h = bitmap.height
        if (w < 16 || h < 16) return ScreenReading(ScreenMode.UNKNOWN, 0, "Imagem pequena")
        var darkBottom = 0; var lightBox = 0; var green = 0; var tan = 0
        val xStep = max(1, w / 96); val yStep = max(1, h / 72)
        var samples = 0
        for (y in 0 until h step yStep) for (x in 0 until w step xStep) {
            val c = bitmap.getPixel(x, y)
            val r = android.graphics.Color.red(c); val g = android.graphics.Color.green(c); val b = android.graphics.Color.blue(c)
            val yn = y.toFloat() / h
            if (yn > .68f && r < 85 && g < 100 && b < 125) darkBottom++
            if (yn > .63f && r > 175 && g > 160 && b > 125) lightBox++
            if (g > r * 1.18 && g > b * 1.10 && g > 75) green++
            if (r > 130 && g > 85 && g < r * .88 && b < g * .9) tan++
            samples++
        }
        val darkRatio = darkBottom.toFloat() / samples
        val lightRatio = lightBox.toFloat() / samples
        val greenRatio = green.toFloat() / samples
        val tanRatio = tan.toFloat() / samples
        return when {
            darkRatio > .10f && (greenRatio > .08f || tanRatio > .025f) -> ScreenReading(ScreenMode.BATTLE, 58, "Painel inferior escuro e cores de interface")
            lightRatio > .045f && darkRatio > .045f -> ScreenReading(ScreenMode.DIALOGUE, 54, "Área clara sobre painel inferior")
            darkRatio > .16f -> ScreenReading(ScreenMode.MENU, 48, "Painel inferior escuro")
            greenRatio > .18f -> ScreenReading(ScreenMode.EXPLORATION, 52, "Predomínio de tons verdes")
            else -> ScreenReading(ScreenMode.UNKNOWN, 25, "Padrão visual não reconhecido")
        }
    }
}

data class Pad(val x: Int, val y: Int)
object LocalBrain {
    fun next(context: Context, reading: ScreenReading): String {
        val prefs = context.getSharedPreferences("agent", Context.MODE_PRIVATE)
        val steps = prefs.getInt("steps", 0)
        val action = when (reading.mode) {
            ScreenMode.BATTLE, ScreenMode.DIALOGUE, ScreenMode.MENU -> "A"
            ScreenMode.EXPLORATION -> listOf("UP", "RIGHT", "DOWN", "LEFT")[steps % 4]
            ScreenMode.UNKNOWN -> "NONE"
        }
        val history = (prefs.getString("action_history", "") ?: "").split(',').filter { it.isNotBlank() }.takeLast(7)
        val updatedHistory = (history + "${reading.mode}:$action").takeLast(8).joinToString(",")
        prefs.edit().putInt("steps", steps + 1).putString("last_mode", reading.mode.name)
            .putString("last_action", action).putString("last_note", reading.note)
            .putString("goal", "Avançar pela região e confirmar interações")
            .putInt("exploration_steps", prefs.getInt("exploration_steps", 0) + if (reading.mode == ScreenMode.EXPLORATION) 1 else 0)
            .putInt("battle_observations", prefs.getInt("battle_observations", 0) + if (reading.mode == ScreenMode.BATTLE) 1 else 0)
            .putString("action_history", updatedHistory)
            .putInt("actions_total", prefs.getInt("actions_total", 0) + if (action == "NONE") 0 else 1).apply()
        return action
    }
}
