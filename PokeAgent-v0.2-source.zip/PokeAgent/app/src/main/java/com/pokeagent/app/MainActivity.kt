package com.pokeagent.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.graphics.PixelFormat
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.EditText
import android.widget.Toast

class MainActivity : Activity() {
    companion object { private const val REQUEST_CAPTURE = 701 }
    private val handler = Handler(Looper.getMainLooper())
    private var floating: LinearLayout? = null
    private var floatingStatus: TextView? = null
    private var windowManager: WindowManager? = null
    private var running = false
    private val prefs by lazy { getSharedPreferences("agent", MODE_PRIVATE) }
    private val statusLoop = object : Runnable {
        override fun run() {
            floatingStatus?.text = CaptureService.status.take(64)
            handler.postDelayed(this, 800)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 16) }
        fun text(s: String, size: Float = 16f) = TextView(this).apply { text = s; textSize = size; setPadding(0, 8, 0, 8) }
        fun button(s: String, action: () -> Unit) = Button(this).apply { text = s; setOnClickListener { action() } }
        root.addView(text("PokéAgent • protótipo local", 22f))
        root.addView(text("1) Ative Acessibilidade. 2) Configure os pontos dos botões do My Boy! (em milésimos da tela: 500 = metade). 3) Conceda captura e abra o controle flutuante."))
        root.addView(button("Abrir configurações de Acessibilidade") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(button("Permitir botão flutuante") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })
        root.addView(button("Iniciar captura de tela") { requestCapture() })
        root.addView(text("Calibração dos botões", 19f))
        root.addView(text("Toque em cada botão para localizar sua posição na tela do jogo. Digite X e Y entre 0 e 1000. Os valores são específicos do layout do My Boy!."))
        val fields = mutableMapOf<String, Pair<EditText, EditText>>()
        listOf("UP" to "Cima", "RIGHT" to "Direita", "DOWN" to "Baixo", "LEFT" to "Esquerda", "A" to "A / confirmar").forEach { (id, label) ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(text(label, 15f), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val ex = EditText(this).apply { hint = "X"; inputType = 2; setText(prefs.getInt("pad_${id}_x", -1).takeIf { it >= 0 }?.toString() ?: "") }
            val ey = EditText(this).apply { hint = "Y"; inputType = 2; setText(prefs.getInt("pad_${id}_y", -1).takeIf { it >= 0 }?.toString() ?: "") }
            row.addView(ex, LinearLayout.LayoutParams(0, 54, 1f)); row.addView(ey, LinearLayout.LayoutParams(0, 54, 1f)); root.addView(row)
            fields[id] = ex to ey
        }
        root.addView(button("Salvar calibração") {
            fields.forEach { (id, pair) ->
                val x = pair.first.text.toString().toIntOrNull(); val y = pair.second.text.toString().toIntOrNull()
                if (x != null && y != null && x in 0..1000 && y in 0..1000) prefs.edit().putInt("pad_${id}_x", x).putInt("pad_${id}_y", y).apply()
            }
            Toast.makeText(this, "Calibração salva", Toast.LENGTH_SHORT).show()
        })
        root.addView(text("O agente usa regras visuais locais simples. Ele pode confundir telas e só deve ser testado com supervisão; pausar/desativar pelo controle flutuante interrompe os toques."))
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this) && CaptureService.status.startsWith("Captura ativa")) showFloating()
    }

    private fun requestCapture() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Deprecated in Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CAPTURE || data == null || resultCode != RESULT_OK) return
        val service = Intent(this, CaptureService::class.java).apply {
            action = CaptureService.ACTION_START
            putExtra(CaptureService.EXTRA_RESULT, resultCode)
            putExtra(CaptureService.EXTRA_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        if (Settings.canDrawOverlays(this)) handler.postDelayed({ showFloating() }, 700)
        else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun stopAgent() {
        running = false; AgentAccessibilityService.enabled = false; CaptureService.automationOn = false
        floating?.findViewWithTag<Button>("toggle")?.text = "INICIAR"
    }

    private fun disableAgent() {
        stopAgent(); startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
    }

    private fun showFloating() {
        if (floating != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xEE18212B.toInt()); setPadding(7, 6, 7, 6) }
        val status = TextView(this).apply { text = "PokéAgent pronto"; textSize = 11f; setTextColor(0xFFFFFFFF.toInt()) }
        val toggle = Button(this).apply { text = "INICIAR"; tag = "toggle"; minWidth = 80; setPadding(6, 2, 6, 2) }
        toggle.setOnClickListener {
            if (running) { stopAgent() }
            else if (AgentAccessibilityService.instance != null && CaptureService.status.startsWith("Captura ativa")) {
                running = true; AgentAccessibilityService.enabled = true; CaptureService.automationOn = true; toggle.text = "PAUSAR"
            } else { Toast.makeText(this, "Inicie a captura e ative Acessibilidade", Toast.LENGTH_SHORT).show() }
        }
        box.addView(status); box.addView(toggle)
        box.addView(Button(this).apply { text = "DESATIVAR"; minWidth = 80; setPadding(6, 2, 6, 2); setOnClickListener { disableAgent() } })
        box.addView(Button(this).apply { text = "FECHAR"; minWidth = 80; setPadding(6, 2, 6, 2); setOnClickListener { disableAgent(); windowManager?.removeView(box); floating = null; floatingStatus = null } })
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START; x = 10; y = 120 }
        box.setOnTouchListener(object : android.view.View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
            override fun onTouch(v: android.view.View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; moved = false; return false }
                    MotionEvent.ACTION_MOVE -> { val dx = event.rawX - downX; val dy = event.rawY - downY; if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true; if (moved) { params.x = startX + dx.toInt(); params.y = startY + dy.toInt(); windowManager?.updateViewLayout(box, params) }; return moved }
                }
                return false
            }
        })
        try { windowManager?.addView(box, params); floating = box; floatingStatus = status; handler.post(statusLoop) }
        catch (_: Exception) { Toast.makeText(this, "Permissão de sobreposição necessária", Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() { stopAgent(); handler.removeCallbacks(statusLoop); floating?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }; floating = null; super.onDestroy() }
}
